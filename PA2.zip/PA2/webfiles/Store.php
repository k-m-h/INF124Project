<html>
    <head>
        <title>Foil Me, Daddy</title>
        <!-- link to main stylesheet -->
        <link rel="stylesheet" type="text/css" href="main.css">
    </head>

    <a href="Store.php" class="topHeader"><h1>Foil Me, <em>Daddy</em></h1></a>
    <nav class="menu">
        <ul>
            <li><a href="Store.php">Home</a></li>
            <li><a href="about.html">About Us</a></li>
            <li><a href="confirmation.html">Order Confirmations</a></li>
        </ul>
    </nav>
    <a href="Store.php">
    <h2>Store</h2>
    </a>
    <table>

<?php
$db = new mysqli('matt-smith-v4.ics.uci.edu', 'inf124db057', 'wRd8MJP2XGWa', 'inf124db057');

if($db->connect_errno > 0){
    die('Unable to connect to database [' . $db->connect_error . ']');
}

$sql = <<<SQL
    SELECT *
    FROM `Products`
SQL;

if(!$result = $db->query($sql)){
    die('There was an error running the query [' . $db->error . ']');
}

while($row = $result->fetch_assoc()){
    echo '      <tr class = "itemBox">';
    echo '        <td class = "picCol">';
    echo '            <a href="item.php?pid=' . $row['pid'] . '">';
    echo '              <img src="' . $row['img'] . '" alt="' . $row['name'] . '" class="fill grow">';
    echo '            </a>';
    echo '        </td>';
    echo '        <td class = "descCol"><p>' . $row['name'] . '</p><p>Price: $' . $row['price'] . '</p><p>Material: ' . $row['material'] . '</p></td>';
    echo '      </tr>';

}
?>

