<html>
    <head>
        <title>Foil Me, Daddy</title>
        <!-- link to main stylesheet -->
        <link rel="stylesheet" type="text/css" href="main.css">
	<?php include 'purchase.php';?>

    </head>

    <a href="Store.html"><h1>Foil Me, <em>Daddy</em></h1></a>
    <nav class="menu">
        <ul>
            <li><a href="Store.html">Home</a></li>
            <li><a href="about.html">About Us</a></li>
        </ul>
    </nav>
    <a href="Store.html">
    <h2>Store</h2>
    </a>
    <h4>Majestic Foil Dragon</h4>
    <img src="https://orig00.deviantart.net/0c23/f/2011/235/1/3/aluminum_foil_oriental_dragon_by_reptanglian-d47l2wd.jpg" alt="MDN" class="fill">
    <cp>Majestic Foil Dragon</p><p>Price: $290</p><p>Material: Reynold's Fine Small Batch Foil</p>
    <p>Please enter all fields outlined in red</p>
    <form action="purchase.php" method="POST">
        <div>
            <label>Product ID:</label>
            <input type="text" name="pid" value="432231" required>
        </div>
        <div>
            <label>Quantity (1-999):</label>
            <input type="text" name="quantity" value="122" required pattern="[0-9]{1,3}">
        </div><br>
        <div>
            <label>First Name:</label>
            <input type="text" name="firstname" value="John"  required>
        </div>
        <div>
            <label>Last Name:</label>
            <input type="text" name="lastname" value="Doe"  required>
        </div><br>
        <div>
            <label>Phone Number (use dashes or spaces):</label>
            <input type="text" name="phone" value="123 123 1234" required pattern="[0-9]{3}[ -][0-9]{3}[ -][0-9]{4}">
        </div><br>
        <div>
            <label>Street Address:</label>
            <input type="text" name="street" value="12312 Test Test" required class="linput">
        </div><br>
        <div>
            <label>City:</label>
            <input type="text" name="city" value="Irvine" required>
        </div>
        <div>
            <label>Zipcode:</label>
            <input type="text" name="zip" value="92131" required>
        </div><br>
        <div>
            <label>Shipping Method:</label>
            <input type="radio" name="shipping" checked="checked" required>Overnight Shipping - $14.99<br>
            <input type="radio" name="shipping">Expedited Shipping (2-3 business days) - $9.99<br>
            <input type="radio" name="shipping">Standard Shipping (5-7 business days) - $4.99<br>
        </div><br>
        <div>
            <label>Credit Card Number:</label>
            <input type="text" name="creditcard" value="1234567890123456" required pattern="[0-9]{16}">
        </div>
        <div>
            <label>CVV:</label>
            <input type="text" name="cvv" value="123"required pattern="[0-9]{3}">
        </div><br><br>
        <input type="submit" value="Send">
        <input type="reset" value="Reset">
    </form>


</html>
