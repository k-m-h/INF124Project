<script>
function hi(pid) {
  document.write(pid);
  var el = document.getElementById('insertHere');
  el.innerHTML = 'the response was' + pid;
}
</script>

<?php

if ( isset( $_POST['submit'])) {
$user = "inf124db057";
$pass = "wRd8MJP2XGWa";
$server = "matt-smith-v4.ics.uci.edu";
$database = "inf124db057";

$connect = mysqli_connect($server, $user, $pass, $database);

if ($connect->connect_error>0) {
        die("Connection failed [" . $connect->connect_error . "]");
}

$mQuery = "SELECT MAX( oid ) as oid FROM `Orders`;";
$maxRow = mysqli_query($connect, $mQuery);
$maxArray = mysqli_fetch_array($maxRow);
$maxId = $maxArray['oid'];

if($maxId >= 0){
   $maxId = $maxId + 1;
} else {
   $maxId = 0;
}

$street = $connect->real_escape_string(htmlspecialchars($_POST['street']));
$creditcard = $connect->real_escape_string($_POST['creditcard']);
$city = $connect->real_escape_string($_POST['city']);
$cvv = intval($_POST['cvv']);
$firstname = $connect->real_escape_string($_POST['firstname']);
$lastname = $connect->real_escape_string($_POST['lastname']);
$phone = $connect->real_escape_string($_POST['phone']);
$pid = intval($_POST['pid']);
$quantity = intval($_POST['quantity']);
$shipping = $_POST['shipping'];
$zip = intval($_POST['zip']);

$sql = "INSERT INTO `Orders` (`oid`, `pid`, `quantity`, `firstName`, `lastName`, `phoneNum`, `addr`, `city`, `zip`, `cardNum`, `cvv`, `ship`) VALUES ('".$maxId."','".$pid."', '".$quantity."', '".$firstname."', '".$lastname."', '".$phone."', '".$street."', '".$city."', '".$zip."', '".$creditcard."', '".$cvv."', '".$shipping."')";

if ($connect->query($sql) === TRUE) {
        echo 'heloo';
        echo '<script type="text/javascript">',
             'hi(' . $maxId . ');',
             '</script>';
} else {
        echo "<br>error: " . $order . "<br>" . $connect->error;
}
mysqli_close($connect);
die();
}
?>




<html>
    <head>
        <title>Foil Me, Daddy</title>
        <!-- link to main stylesheet -->
        <link rel="stylesheet" type="text/css" href="main.css">

    </head>

    <a href="Store.php"><h1>Foil Me, <em>Daddy</em></h1></a>
    <nav class="menu">
        <ul>
            <li><a href="Store.php">Home</a></li>
            <li><a href="about.html">About Us</a></li>
        </ul>
    </nav>
    <a href="Store.php">
    <h2>Store</h2>
    </a>

<?php
$db = new mysqli('matt-smith-v4.ics.uci.edu', 'inf124db057', 'wRd8MJP2XGWa', 'inf124db057');

if($db->connect_errno > 0){
    die('Unable to connect to database [' . $db->connect_error . ']');
}

$sql = "SELECT * FROM `Products` WHERE pid = " . htmlspecialchars($_GET["pid"]);

if(!$result = $db->query($sql)){
    die('There was an error running the query [' . $db->error . ']');
}

while($row = $result->fetch_assoc()){
    echo '    <h4>' . $row['name'] . '</h4>';
    echo '    <img src="' . $row['img'] . '" alt="' . $row['name'] . '\" class="fill\">';
    echo '    <p>' . $row['name'] . '</p><p>Price: $' . $row['price'] . '</p><p>Material: ' . $row['material'] . '</p>';
    echo '    <p>Please enter all fields outlined in red</p>';
    echo '    <form action="" method="POST">';
    echo '        <div>';
    echo '        <input type="text" name="pid" value="' . $row['pid'] . '" required>';

}
?>

        </div>
        <div>
            <label>Quantity (1-999):</label>
            <input type="text" name="quantity" required pattern="[0-9]{1,3}">
        </div><br>
        <div>
            <label>First Name:</label>
            <input type="text" name="firstname"  required>
        </div>
        <div>
            <label>Last Name:</label>
            <input type="text" name="lastname" required>
        </div><br>
        <div>
            <label>Phone Number (use dashes or spaces):</label>
            <input type="text" name="phone" required pattern="[0-9]{3}[ -][0-9]{3}[ -][0-9]{4}">
        </div><br>
        <div>
            <label>Street Address:</label>
            <input type="text" name="street" required class="linput">
        </div><br>
        <div>
            <label>Zipcode:</label>
            <input type="text" name="zip" id="zip" required>
        </div>
        <div>
            <label>City:</label>
            <input type="text" name="city" id="city" required class="sinput">
        </div>
	<div>
            <label>State:</label>
            <input type="text" name="state" id="state" class="sinput" required>
	</div>
	<br>
        <div>
            <label>Shipping Method:</label>
            <input type="radio" name="shipping" value="Overnight" checked="checked" required>Overnight Shipping - $14.99<br>
            <input type="radio" name="shipping" value="Expedited">Expedited Shipping (2-3 business days) - $9.99<br>
            <input type="radio" name="shipping" value="Standard" >Standard Shipping (5-7 business days) - $4.99<br>
        </div><br>
        <div>
            <label>Credit Card Number:</label>
            <input type="text" name="creditcard" required pattern="[0-9]{16}">
        </div>
        <div>
            <label>CVV:</label>
            <input type="text" name="cvv" required pattern="[0-9]{3}">
        </div><br><br>
        <input type="submit" value="Submit" name="submit">
        <input type="reset" value="Reset">
<span id="insertHere"></span>
    <script>
    (function() {
        var httpRequest;
        document.getElementById("zip").addEventListener('keyup', findCity);

        function findCity() {
        httpRequest = new XMLHttpRequest();
        var zip = parseInt(document.getElementById("zip").value);
        if (!httpRequest) {
            alert('Giving up :( Cannot create an XMLHTTP instance');
            return false;
        }
        httpRequest.onreadystatechange = alertContents;
        httpRequest.open('POST', 'zipCity.php');
        httpRequest.setRequestHeader("content-type", "application/x-www-form-urlencoded");
        httpRequest.send('zip=' + zip);
        }

        function alertContents() {
        if (httpRequest.readyState === XMLHttpRequest.DONE) {
            if (httpRequest.status === 200) {
            document.getElementById('city').value = JSON.parse(httpRequest.responseText)['city'];
            document.getElementById('state').value = JSON.parse(httpRequest.responseText)['state'];
	    } else {
                alert('There was a problem with the request.');
                }  
            }
        }
    })();
    </script>
    </form>
</html>
