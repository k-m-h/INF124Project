<?php
  $user = "inf124db057";
  $pass = "wRd8MJP2XGWa";
  $server = "matt-smith-v4.ics.uci.edu";
  $database = "inf124db057";

  $connect = mysqli_connect($server, $user, $pass, $database);
  if ($connect->connect_error>0) {
          die("Connection failed [" . $connect->connect_error . "]");
  }
  $sql = "SELECT * FROM `TaxRate` WHERE `zip` = " . intval($_POST['zip']);
  $row = mysqli_query($connect, $sql);
  $array = mysqli_fetch_object($row);
  $zipArray = "tax"=>$array->tax;
  echo json_encode($zipArray);
  mysqli_close($connect);
  die();
?>
