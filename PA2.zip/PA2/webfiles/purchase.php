<script>
function hi(pid) {
  var el = document.getElementById('insertHere');
  el.innerHTML = 'the response was' + pid;
}
</script>

<?php

if ( isset( $_POST['submit'])) {
$user = "inf124db057";
$pass = "wRd8MJP2XGWa";
$server = "matt-smith-v4.ics.uci.edu";
$database = "inf124db057";

$connect = mysqli_connect($server, $user, $pass, $database);

if ($connect->connect_error>0) {
	die("Connection failed [" . $connect->connect_error . "]");
}

$mQuery = "SELECT MAX( oid ) as oid FROM `Orders`;";
$maxRow = mysqli_query($connect, $mQuery);
$maxArray = mysqli_fetch_array($maxRow);
$maxId = $maxArray['oid'];

if($maxId >= 0){
   $maxId = $maxId + 1;
} else {
   $maxId = 0;
}

$street = $connect->real_escape_string(htmlspecialchars($_POST['street']));
$creditcard = $connect->real_escape_string($_POST['creditcard']);
$city = $connect->real_escape_string($_POST['city']);
$cvv = intval($_POST['cvv']);
$firstname = $connect->real_escape_string($_POST['firstname']);
$lastname = $connect->real_escape_string($_POST['lastname']);
$phone = $connect->real_escape_string($_POST['phone']);
$pid = intval($_POST['pid']);
$quantity = intval($_POST['quantity']);
$shipping = $_POST['shipping'];
$zip = intval($_POST['zip']);

$sql = "INSERT INTO `Orders` (`oid`, `pid`, `quantity`, `firstName`, `lastName`, `phoneNum`, `addr`, `city`, `zip`, `cardNum`, `cvv`, `ship`) VALUES ('".$maxId."','".$pid."', '".$quantity."', '".$firstname."', '".$lastname."', '".$phone."', '".$street."', '".$city."', '".$zip."', '".$creditcard."', '".$cvv."', '".$shipping."')";

if ($connect->query($sql) === TRUE) {
        echo 
        '<html>',
'    <head>',
'        <title>Foil Me, Daddy</title>',
'        <!-- link to main stylesheet -->',
'        <link rel="stylesheet" type="text/css" href="main.css">',
'    </head>',
'    <a href="Store.html"><h1>Foil Me, <em>Daddy</em></h1></a>',
'    <nav class="menu">',
'        <ul>',
'            <li><a href="Store.php">Home</a></li>',
'            <li><a href="about.html">About Us</a></li>',
'        </ul>',
'    </nav>',
'    <a href="Store.php">',
'    <h2>Store</h2>',
'    </a>',
        '<p>Thank you for your purchase.  Your order number is ' . $maxId . '.</p>';
} else {
	echo "<br>error: " . $order . "<br>" . $connect->error;
}
mysqli_close($connect);
die();
}
?>

