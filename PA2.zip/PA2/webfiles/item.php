

<html>
    <head>
        <title>Foil Me, Daddy</title>
        <!-- link to main stylesheet -->
        <link rel="stylesheet" type="text/css" href="main.css">
        <?php require 'purchase.php';?>

    </head>
    <span id="insertHere"></span>
    <a href="Store.php"  class="topHeader"><h1>Foil Me, <em>Daddy</em></h1></a>
    <nav class="menu">
        <ul>
            <li><a href="Store.php">Home</a></li>
            <li><a href="about.html">About Us</a></li>
            <li><a href="confirmation.html">Order Confirmations</a></li>
        </ul>
    </nav>
    <a href="Store.php">
    <h2>Store</h2>
    </a>

<?php
$db = new mysqli('matt-smith-v4.ics.uci.edu', 'inf124db057', 'wRd8MJP2XGWa', 'inf124db057');

if($db->connect_errno > 0){
    die('Unable to connect to database [' . $db->connect_error . ']');
}

$sql = "SELECT * FROM `Products` WHERE pid = " . htmlspecialchars($_GET["pid"]);

if(!$result = $db->query($sql)){
    die('There was an error running the query [' . $db->error . ']');
}

while($row = $result->fetch_assoc()){
    echo '    <h4>' . $row['name'] . '</h4>';
    echo '    <img src="' . $row['img'] . '" alt="' . $row['name'] . '\" class="fill\">';
    echo '    <p>' . $row['name'] . '</p><p>Price: $' . $row['price'] . '</p><p>Material: ' . $row['material'] . '</p>';
    echo '    <p>Please enter all fields outlined in red</p>';
    echo '    <form action="purchase.php" method="POST">';
    echo '        <div>';
    echo '        <input type="text" name="pid" value="' . $row['pid'] . '" required>';

}
?>

        </div>
        <div>
            <label>Quantity (1-999):</label>
            <input type="text" name="quantity" required pattern="[0-9]{1,3}">
        </div><br>
        <div>
            <label>First Name:</label>
            <input type="text" name="firstname"  required>
        </div>
        <div>
            <label>Last Name:</label>
            <input type="text" name="lastname" required>
        </div><br>
        <div>
            <label>Phone Number (use dashes or spaces):</label>
            <input type="text" name="phone" id="phone" required maxlength="12">
        </div><br>
        <div>
            <label>Street Address:</label>
            <input type="text" name="street" required class="linput">
        </div><br>
        <div>
            <label>Zipcode:</label>
            <input type="text" name="zip" id="zip" required>
        </div>
        <div>
            <label>City:</label>
            <input type="text" name="city" id="city" required class="sinput">
        </div>
        <div>
            <label>State:</label>
            <input type="text" name="state" id="state" class="sinput" required>
        </div>
        <br>
        <div>
            <label>Shipping Method:</label>
            <input type="radio" name="shipping" value="Overnight" checked="checked" required>Overnight Shipping - $14.99<br>
            <input type="radio" name="shipping" value="Expedited">Expedited Shipping (2-3 business days) - $9.99<br>
            <input type="radio" name="shipping" value="Standard" >Standard Shipping (5-7 business days) - $4.99<br>
        </div><br>
        <div>
            <label>Credit Card Number:</label>
            <input type="text" name="creditcard" required pattern="[0-9]{16}">
        </div>
        <div>
            <label>CVV:</label>
            <input type="text" name="cvv" required pattern="[0-9]{3}">
        </div><br><br>
        <input id='purchase' class="bttn" type="submit" value="Submit" name="submit">
        <input class="bttn"type="reset" value="Reset">
        <span id="insertHere"></span>
    <script>
    (function() {
        var httpRequest;
        document.getElementById("zip").addEventListener('keyup', findCity);
	document.getElementById("phone").addEventListener('keydown', phoneThing); 

	function phoneThing(event) {
        if (event.which > 57) {
            event.preventDefault();
        } else if (event.which < 48) {
            if (key != 8 && key != 9 && key != 37 && key != 39 ) {
                e.preventDefault();
            }
        } else {
            var phone = document.getElementById('phone').value;
            if (phone.length === 3 || phone.length === 7)
            {
                    document.getElementById("phone").value += "-";
                }
            }
	}

        function findCity() {
        httpRequest = new XMLHttpRequest();
        var zip = parseInt(document.getElementById("zip").value);
        if (!httpRequest) {
            alert('Giving up :( Cannot create an XMLHTTP instance');
            return false;
        }
        httpRequest.onreadystatechange = alertContents;
        httpRequest.open('POST', 'zipCity.php');
        httpRequest.setRequestHeader("content-type", "application/x-www-form-urlencoded");
        httpRequest.send('zip=' + zip);
        }

        function alertContents() {
        if (httpRequest.readyState === XMLHttpRequest.DONE) {
            if (httpRequest.status === 200) {
            document.getElementById('city').value = JSON.parse(httpRequest.responseText)['city'];
            document.getElementById('state').value = JSON.parse(httpRequest.responseText)['state'];
            } else {
                alert('There was a problem with the request.');
                }
            }
        }
    })();
    </script>
    </form>
</html>
